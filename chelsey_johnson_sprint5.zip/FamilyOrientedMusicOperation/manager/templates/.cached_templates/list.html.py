# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1519664458.5223227
_enable_loop = True
_template_filename = 'C:/Users/Chelsey/Documents/IS411_413/FOMO/fomo/FamilyOrientedMusicOperation/manager/templates/list.html'
_template_uri = 'list.html'
_source_encoding = 'utf-8'
import django_mako_plus
import django_mako_plus
_exports = ['center']


def _mako_get_namespace(context, name):
    try:
        return context.namespaces[(__name__, name)]
    except KeyError:
        _mako_generate_namespaces(context)
        return context.namespaces[(__name__, name)]
def _mako_generate_namespaces(context):
    pass
def _mako_inherit(template, context):
    _mako_generate_namespaces(context)
    return runtime._inherit_from(context, 'app_base.htm', _template_uri)
def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        products = context.get('products', UNDEFINED)
        def center():
            return render_center(context._locals(__M_locals))
        __M_writer = context.writer()
        __M_writer('\r\n\r\n\r\n')
        if 'parent' not in context._data or not hasattr(context._data['parent'], 'center'):
            context['self'].center(**pageargs)
        

        __M_writer('\r\n\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


def render_center(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        products = context.get('products', UNDEFINED)
        def center():
            return render_center(context)
        __M_writer = context.writer()
        __M_writer('\r\n   <br>\r\n   <h1 class="text-center">Product Overview</h1>\r\n    <table class=\'table table-hover\'>\r\n        <thead>\r\n            <tr>\r\n                <th>\r\n                    <td>Name</td>\r\n                    <td>Product Type</td>\r\n                    <td>Price</td>\r\n                    <td>Category</td>\r\n                    <td>Quantity</td>\r\n                    <td>Edit</td>\r\n                    <td>Delete</td>\r\n                </th>\r\n            </tr>\r\n        </thead>\r\n        <tbody>\r\n')
        for p in products:
            __M_writer('            <tr>\r\n                <td></td>\r\n                <td>')
            __M_writer(str( p.name ))
            __M_writer('</td>\r\n                <!-- ')
            __M_writer(str(p.__class__.__name__))
            __M_writer(' -->\r\n                <td>')
            __M_writer(str( p.TITLE ))
            __M_writer('</td>\r\n                <td>$')
            __M_writer(str( p.price ))
            __M_writer('</td>\r\n                <td>')
            __M_writer(str( p.category ))
            __M_writer('</td>\r\n                <td>')
            __M_writer(str( p.get_quantity() ))
            __M_writer('</td>\r\n                <td><a href="/manager/edit/')
            __M_writer(str( p.id ))
            __M_writer('" ><span class="glyphicon glyphicon-pencil"></span></a></td>\r\n                <td><a href="/manager/delete/')
            __M_writer(str( p.id ))
            __M_writer('"><span class="glyphicon glyphicon-remove"></span></a></td>\r\n            </tr>\r\n')
        __M_writer("        </tbody>\r\n    </table>\r\n\r\n    <a href='/manager/create'><button class='btn btn-primary'>Create</button></a>\r\n \r\n")
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "C:/Users/Chelsey/Documents/IS411_413/FOMO/fomo/FamilyOrientedMusicOperation/manager/templates/list.html", "uri": "list.html", "source_encoding": "utf-8", "line_map": {"29": 0, "37": 1, "42": 40, "48": 4, "55": 4, "56": 22, "57": 23, "58": 25, "59": 25, "60": 26, "61": 26, "62": 27, "63": 27, "64": 28, "65": 28, "66": 29, "67": 29, "68": 30, "69": 30, "70": 31, "71": 31, "72": 32, "73": 32, "74": 35, "80": 74}}
__M_END_METADATA
"""
