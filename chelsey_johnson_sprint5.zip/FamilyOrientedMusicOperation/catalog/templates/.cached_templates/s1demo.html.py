# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1520468295.9029276
_enable_loop = True
_template_filename = 'C:/Users/Chelsey/Documents/IS411_413/FOMO/FOMO/FamilyOrientedMusicOperation/catalog/templates/s1demo.html'
_template_uri = 's1demo.html'
_source_encoding = 'utf-8'
import django_mako_plus
import django_mako_plus
_exports = ['center']


def _mako_get_namespace(context, name):
    try:
        return context.namespaces[(__name__, name)]
    except KeyError:
        _mako_generate_namespaces(context)
        return context.namespaces[(__name__, name)]
def _mako_generate_namespaces(context):
    pass
def _mako_inherit(template, context):
    _mako_generate_namespaces(context)
    return runtime._inherit_from(context, '/homepage/templates/app_base.htm', _template_uri)
def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        def center():
            return render_center(context._locals(__M_locals))
        product = context.get('product', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('\r\n\r\n')
        if 'parent' not in context._data or not hasattr(context._data['parent'], 'center'):
            context['self'].center(**pageargs)
        

        return ''
    finally:
        context.caller_stack._pop_frame()


def render_center(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        def center():
            return render_center(context)
        product = context.get('product', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('\r\n    <!-- <div id="s1container">\r\n\r\n    </div> -->\r\n<ul id="product_list">\r\n    <li>hi</li>\r\n    <li>\r\n        <div class="price">')
        __M_writer(str( product.price ))
        __M_writer('</div>\r\n        <div class="title">')
        __M_writer(str( product.name ))
        __M_writer('</div>\r\n        \r\n    </li>\r\n    <li>chocolate</li>\r\n</ul>\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "C:/Users/Chelsey/Documents/IS411_413/FOMO/FOMO/FamilyOrientedMusicOperation/catalog/templates/s1demo.html", "uri": "s1demo.html", "source_encoding": "utf-8", "line_map": {"29": 0, "37": 1, "47": 3, "54": 3, "55": 10, "56": 10, "57": 11, "58": 11, "64": 58}}
__M_END_METADATA
"""
