# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1520524870.1249268
_enable_loop = True
_template_filename = 'C:/Users/Chelsey/Documents/IS411_413/FOMO/FOMO/FamilyOrientedMusicOperation/catalog/templates/index.products.html'
_template_uri = 'index.products.html'
_source_encoding = 'utf-8'
import django_mako_plus
import django_mako_plus
_exports = []


def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        products = context.get('products', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('<div id="catalog">\r\n    <ul id="product_list">\r\n')
        for p in products:
            __M_writer('            <li>\r\n                <div class="price">')
            __M_writer(str( p.price ))
            __M_writer('</div>\r\n                <div><img class="image" src="')
            __M_writer(str(p.image_url()))
            __M_writer('"></div>\r\n                <div class="title">')
            __M_writer(str( p.name ))
            __M_writer('</div>\r\n            </li>\r\n')
        __M_writer('    </ul>\r\n</div>')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "C:/Users/Chelsey/Documents/IS411_413/FOMO/FOMO/FamilyOrientedMusicOperation/catalog/templates/index.products.html", "uri": "index.products.html", "source_encoding": "utf-8", "line_map": {"18": 0, "24": 1, "25": 3, "26": 4, "27": 5, "28": 5, "29": 6, "30": 6, "31": 7, "32": 7, "33": 10, "39": 33}}
__M_END_METADATA
"""
