# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1520525307.2661777
_enable_loop = True
_template_filename = 'C:/Users/Chelsey/Documents/IS411_413/FOMO/FOMO/FamilyOrientedMusicOperation/catalog/templates/index.html'
_template_uri = 'index.html'
_source_encoding = 'utf-8'
import django_mako_plus
import django_mako_plus
_exports = ['head', 'left', 'center']


def _mako_get_namespace(context, name):
    try:
        return context.namespaces[(__name__, name)]
    except KeyError:
        _mako_generate_namespaces(context)
        return context.namespaces[(__name__, name)]
def _mako_generate_namespaces(context):
    pass
def _mako_inherit(template, context):
    _mako_generate_namespaces(context)
    return runtime._inherit_from(context, 'homepage/templates/app_base.htm', _template_uri)
def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        def head():
            return render_head(context._locals(__M_locals))
        page_count = context.get('page_count', UNDEFINED)
        def left():
            return render_left(context._locals(__M_locals))
        def center():
            return render_center(context._locals(__M_locals))
        page = context.get('page', UNDEFINED)
        id = context.get('id', UNDEFINED)
        category = context.get('category', UNDEFINED)
        categories = context.get('categories', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('\r\n\r\n')
        if 'parent' not in context._data or not hasattr(context._data['parent'], 'head'):
            context['self'].head(**pageargs)
        

        __M_writer('\r\n')
        if 'parent' not in context._data or not hasattr(context._data['parent'], 'left'):
            context['self'].left(**pageargs)
        

        __M_writer('\r\n\r\n\r\n')
        if 'parent' not in context._data or not hasattr(context._data['parent'], 'center'):
            context['self'].center(**pageargs)
        

        __M_writer('\r\n\r\n\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


def render_head(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        def head():
            return render_head(context)
        __M_writer = context.writer()
        __M_writer('\r\n<br><br>\r\n\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


def render_left(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        id = context.get('id', UNDEFINED)
        category = context.get('category', UNDEFINED)
        def left():
            return render_left(context)
        categories = context.get('categories', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('\r\n    <ul id="category_list">\r\n        <li class="')
        __M_writer(str( 'active' if category is None else ''))
        __M_writer('"><a href="/catalog/index/">All Products</a></li>\r\n')
        for c in categories:
            __M_writer('            <li class="')
            __M_writer(str( 'active' if id == c.id else ''))
            __M_writer('"><a href="/catalog/index/')
            __M_writer(str( c.id ))
            __M_writer('/">')
            __M_writer(str( c.name ))
            __M_writer('</a></li>\r\n')
        __M_writer('    </ul>\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


def render_center(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        page_count = context.get('page_count', UNDEFINED)
        def center():
            return render_center(context)
        page = context.get('page', UNDEFINED)
        category = context.get('category', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('\r\n\r\n<h1 class="text-center">')
        __M_writer(str( 'Products' if category is None else category.name ))
        __M_writer('</h1>\r\n\r\n<div id="paginator" class="text-right">\r\n        <a id="previous_page"><span aria-hidden="true">&laquo;</span></a>\r\n        Page <span id="page_number">')
        __M_writer(str( page ))
        __M_writer('</span> of ')
        __M_writer(str( page_count ))
        __M_writer('\r\n        <a id="next_page"><span aria-hidden="true">&raquo;</span></a>\r\n    </div>\r\n    <div id="product_container">\r\n        ')
        runtime._include_file(context, 'index.products.html', _template_uri)
        __M_writer('\r\n    </div>\r\n\r\n    \r\n\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "C:/Users/Chelsey/Documents/IS411_413/FOMO/FOMO/FamilyOrientedMusicOperation/catalog/templates/index.html", "uri": "index.html", "source_encoding": "utf-8", "line_map": {"29": 0, "45": 1, "50": 6, "55": 14, "60": 32, "66": 3, "72": 3, "78": 7, "87": 7, "88": 9, "89": 9, "90": 10, "91": 11, "92": 11, "93": 11, "94": 11, "95": 11, "96": 11, "97": 11, "98": 13, "104": 17, "113": 17, "114": 19, "115": 19, "116": 23, "117": 23, "118": 23, "119": 23, "120": 27, "121": 27, "127": 121}}
__M_END_METADATA
"""
