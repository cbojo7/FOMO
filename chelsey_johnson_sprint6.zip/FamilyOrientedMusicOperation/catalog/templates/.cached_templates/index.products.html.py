# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1521468987.4401765
_enable_loop = True
_template_filename = 'C:/Users/Chelsey/Documents/IS411_413/FOMO/FOMO/FamilyOrientedMusicOperation/catalog/templates/index.products.html'
_template_uri = 'index.products.html'
_source_encoding = 'utf-8'
import django_mako_plus
import django_mako_plus
_exports = []


def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        products = context.get('products', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('<div id="catalog">\r\n\r\n    <ul id="product_list">\r\n')
        for p in products:
            __M_writer('            \r\n            <li><a href="/catalog/detail/')
            __M_writer(str( p.id ))
            __M_writer('">\r\n                <div class="price">')
            __M_writer(str( p.price ))
            __M_writer('</div>\r\n                <div><img class="image" src="')
            __M_writer(str(p.image_url()))
            __M_writer('"></div>\r\n                <div class="title">')
            __M_writer(str( p.name ))
            __M_writer('</div></a>\r\n            </li>\r\n')
        __M_writer('    </ul>\r\n</div>')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "C:/Users/Chelsey/Documents/IS411_413/FOMO/FOMO/FamilyOrientedMusicOperation/catalog/templates/index.products.html", "uri": "index.products.html", "source_encoding": "utf-8", "line_map": {"18": 0, "24": 1, "25": 4, "26": 5, "27": 6, "28": 6, "29": 7, "30": 7, "31": 8, "32": 8, "33": 9, "34": 9, "35": 12, "41": 35}}
__M_END_METADATA
"""
