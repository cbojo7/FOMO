# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1521562032.1171772
_enable_loop = True
_template_filename = 'C:/Users/Chelsey/Documents/IS411_413/FOMO/FOMO/FamilyOrientedMusicOperation/catalog/templates/detail.html'
_template_uri = 'detail.html'
_source_encoding = 'utf-8'
import django_mako_plus
import django_mako_plus
_exports = ['center']


def _mako_get_namespace(context, name):
    try:
        return context.namespaces[(__name__, name)]
    except KeyError:
        _mako_generate_namespaces(context)
        return context.namespaces[(__name__, name)]
def _mako_generate_namespaces(context):
    pass
def _mako_inherit(template, context):
    _mako_generate_namespaces(context)
    return runtime._inherit_from(context, 'app_base.htm', _template_uri)
def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        def center():
            return render_center(context._locals(__M_locals))
        product = context.get('product', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('\r\n\r\n')
        if 'parent' not in context._data or not hasattr(context._data['parent'], 'center'):
            context['self'].center(**pageargs)
        

        return ''
    finally:
        context.caller_stack._pop_frame()


def render_center(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        def center():
            return render_center(context)
        product = context.get('product', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('\r\n    <div id="catalog">\r\n        <h1>')
        __M_writer(str( product.name ))
        __M_writer('</h1>\r\n        <ul class="thumbnail_list">\r\n')
        for i in product.images_urls():
            __M_writer('                <li><img src="')
            __M_writer(str( i ))
            __M_writer('" class="thumbnail_image"></li>\r\n')
        __M_writer('        </ul>\r\n        <img src="')
        __M_writer(str( product.image_url() ))
        __M_writer('" class="main_image">\r\n        <div class="description">\r\n            <p>')
        __M_writer(str( product.description ))
        __M_writer('</p>\r\n        </div>\r\n        \r\n    </div>\r\n    <div>\r\n')
        if product.TITLE == "Bulk":
            __M_writer('            <div id="quantity">\r\n                <h4>Quantity</h4>\r\n                <select>\r\n                    <option value="1">1</option>\r\n                    <option value="2">2</option>\r\n                    <option value="3">3</option>\r\n                    <option value="4">4</option>\r\n                    <option value="5">5</option>\r\n                    <option value="6">6</option>\r\n                    <option value="7">7</option>\r\n                    <option value="8">8</option>\r\n                    <option value="9">9</option>\r\n                    <option value="10">10</option>\r\n                </select>\r\n            </div>\r\n')
        __M_writer('        <br>\r\n        <button class="btn btn-primary" href="#">Buy Now</button>\r\n    </div>\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "C:/Users/Chelsey/Documents/IS411_413/FOMO/FOMO/FamilyOrientedMusicOperation/catalog/templates/detail.html", "uri": "detail.html", "source_encoding": "utf-8", "line_map": {"29": 0, "37": 1, "47": 3, "54": 3, "55": 5, "56": 5, "57": 7, "58": 8, "59": 8, "60": 8, "61": 10, "62": 11, "63": 11, "64": 13, "65": 13, "66": 18, "67": 19, "68": 35, "74": 68}}
__M_END_METADATA
"""
