# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1521558561.0661254
_enable_loop = True
_template_filename = 'C:/Users/Chelsey/Documents/IS411_413/FOMO/FOMO/FamilyOrientedMusicOperation/catalog/templates/app_base.htm'
_template_uri = 'app_base.htm'
_source_encoding = 'utf-8'
import django_mako_plus
import django_mako_plus
_exports = ['navigation', 'left', 'footer', 'right']


from catalog import models as cmod 

from datetime import datetime 

def _mako_get_namespace(context, name):
    try:
        return context.namespaces[(__name__, name)]
    except KeyError:
        _mako_generate_namespaces(context)
        return context.namespaces[(__name__, name)]
def _mako_generate_namespaces(context):
    pass
def _mako_inherit(template, context):
    _mako_generate_namespaces(context)
    return runtime._inherit_from(context, '/homepage/templates/base.htm', _template_uri)
def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        def navigation():
            return render_navigation(context._locals(__M_locals))
        STATIC_URL = context.get('STATIC_URL', UNDEFINED)
        def left():
            return render_left(context._locals(__M_locals))
        request = context.get('request', UNDEFINED)
        def footer():
            return render_footer(context._locals(__M_locals))
        id = context.get('id', UNDEFINED)
        def right():
            return render_right(context._locals(__M_locals))
        __M_writer = context.writer()
        __M_writer('\r\n')
        __M_writer('\r\n\r\n')
        if 'parent' not in context._data or not hasattr(context._data['parent'], 'navigation'):
            context['self'].navigation(**pageargs)
        

        __M_writer('\r\n\r\n\r\n\r\n\r\n')
        if 'parent' not in context._data or not hasattr(context._data['parent'], 'left'):
            context['self'].left(**pageargs)
        

        __M_writer('\r\n\r\n')
        if 'parent' not in context._data or not hasattr(context._data['parent'], 'footer'):
            context['self'].footer(**pageargs)
        

        __M_writer('\r\n\r\n')
        if 'parent' not in context._data or not hasattr(context._data['parent'], 'right'):
            context['self'].right(**pageargs)
        

        return ''
    finally:
        context.caller_stack._pop_frame()


def render_navigation(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        def navigation():
            return render_navigation(context)
        request = context.get('request', UNDEFINED)
        STATIC_URL = context.get('STATIC_URL', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('\r\n   \r\n    <nav class="navbar navbar-default">\r\n        <div class="container-fluid">\r\n            <div class="navbar-header">\r\n                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">\r\n                <a class="navbar-brand" href="/homepage/index"> <img src="')
        __M_writer(str( STATIC_URL ))
        __M_writer('homepage/media/icon.png">FOMO</a>\r\n            </div>\r\n            <ul class="nav navbar-nav">\r\n                <!-- nav-brand -->\r\n                <li><img src="')
        __M_writer(str( STATIC_URL ))
        __M_writer('homepage/media/icon.png" id="icon"></li>\r\n                <li class="')
        __M_writer(str( 'active' if request.dmp.page == 'index' else '' ))
        __M_writer('"><a href="/index">Home</a></li>\r\n                <li class="')
        __M_writer(str( 'active' if request.dmp.page == 'about' else '' ))
        __M_writer('"><a href="/about">About Us</a></li>\r\n                <li class="')
        __M_writer(str( 'active' if request.dmp.page == 'contact' else '' ))
        __M_writer('"><a href="/contact">Contact</a></li>\r\n                <li class="')
        __M_writer(str( 'active' if request.dmp.page == 'terms' else '' ))
        __M_writer('"><a href="/terms">Terms</a></li>\r\n                <li class="')
        __M_writer(str( 'active' if request.dmp.page == 'faq' else '' ))
        __M_writer('"><a href="/faq">FAQ</a></li>\r\n                <li class="')
        __M_writer(str( 'active' if request.dmp.page == 'catalog' else '' ))
        __M_writer('"><a href="/catalog/index">Catalog</a></li>\r\n            </ul>\r\n            <ul class="nav navbar-nav navbar-right">\r\n                <li class="dropdown">\r\n                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">Sign-in<b class="caret"></b></a>\r\n                    <ul class="dropdown-menu">\r\n                        <li><a href="/account/login">Sign-in</a></li>\r\n                        <li><a href="/account/signup">Register</a></li>\r\n                    </ul>\r\n                 </li>\r\n            </ul>\r\n        </div>\r\n    </nav>\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


def render_left(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        def left():
            return render_left(context)
        id = context.get('id', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('\r\n\r\n    <ul id="category-list">\r\n        <li class="$\'active\' if category is None else \'\' }"><a href="/catalog/index/">All Products</a></li>\r\n')
        for c in cmod.Category.objects.all():
            __M_writer('            <li class="')
            __M_writer(str( 'active' if id == c.id else ''))
            __M_writer('"><a href="/catalog/index/')
            __M_writer(str( c.id ))
            __M_writer('/">')
            __M_writer(str( c.name ))
            __M_writer('</a></li>\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


def render_footer(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        def footer():
            return render_footer(context)
        __M_writer = context.writer()
        __M_writer('\r\n    <footer class="footer">\r\n        <hr />\r\n        ')
        __M_writer('\r\n            &copy;')
        __M_writer(str( datetime.now().year ))
        __M_writer(' Family Oriented Music Operation. All rights reserved.\r\n            <br />\r\n    </footer>\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


def render_right(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        request = context.get('request', UNDEFINED)
        def right():
            return render_right(context)
        __M_writer = context.writer()
        __M_writer('\r\n    <h3 id="last_five_title">Recently Viewed:</h3>\r\n    <ol id="last_five_list">\r\n')
        if request.lastFive is not None:
            for product in request.lastFive[1:6]:
                __M_writer('                <li>\r\n                    <a href="/catalog/detail/')
                __M_writer(str( product.id ))
                __M_writer('/">\r\n                        <div><img class="product_image" src="')
                __M_writer(str( product.image_url() ))
                __M_writer('" /></div>\r\n                        <div class="product_title">')
                __M_writer(filters.html_escape(str( product.name )))
                __M_writer('</div>\r\n                    </a>\r\n                </li>\r\n')
        __M_writer('    </ol>\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "C:/Users/Chelsey/Documents/IS411_413/FOMO/FOMO/FamilyOrientedMusicOperation/catalog/templates/app_base.htm", "uri": "app_base.htm", "source_encoding": "utf-8", "line_map": {"18": 2, "20": 50, "33": 0, "49": 1, "50": 2, "55": 33, "60": 45, "65": 54, "75": 4, "83": 4, "84": 10, "85": 10, "86": 14, "87": 14, "88": 15, "89": 15, "90": 16, "91": 16, "92": 17, "93": 17, "94": 18, "95": 18, "96": 19, "97": 19, "98": 20, "99": 20, "105": 38, "112": 38, "113": 42, "114": 43, "115": 43, "116": 43, "117": 43, "118": 43, "119": 43, "120": 43, "126": 47, "132": 47, "133": 50, "134": 51, "135": 51, "141": 56, "148": 56, "149": 59, "150": 60, "151": 61, "152": 62, "153": 62, "154": 63, "155": 63, "156": 64, "157": 64, "158": 69, "164": 158}}
__M_END_METADATA
"""
