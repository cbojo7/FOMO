# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1516806256.5008457
_enable_loop = True
_template_filename = 'C:/Users/Chelsey/Documents/IS411_413/FOMO/FOMO/FamilyOrientedMusicOperation/homepage/templates/about.html'
_template_uri = 'about.html'
_source_encoding = 'utf-8'
import django_mako_plus
_exports = ['head', 'center']


def _mako_get_namespace(context, name):
    try:
        return context.namespaces[(__name__, name)]
    except KeyError:
        _mako_generate_namespaces(context)
        return context.namespaces[(__name__, name)]
def _mako_generate_namespaces(context):
    pass
def _mako_inherit(template, context):
    _mako_generate_namespaces(context)
    return runtime._inherit_from(context, 'app_base.htm', _template_uri)
def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        def head():
            return render_head(context._locals(__M_locals))
        def center():
            return render_center(context._locals(__M_locals))
        __M_writer = context.writer()
        __M_writer('\r\n\r\n')
        if 'parent' not in context._data or not hasattr(context._data['parent'], 'head'):
            context['self'].head(**pageargs)
        

        __M_writer('\r\n\r\n')
        if 'parent' not in context._data or not hasattr(context._data['parent'], 'center'):
            context['self'].center(**pageargs)
        

        __M_writer('\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


def render_head(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        def head():
            return render_head(context)
        __M_writer = context.writer()
        __M_writer('\r\n    <h1 class="center-head">About Us</h1>\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


def render_center(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        def center():
            return render_center(context)
        __M_writer = context.writer()
        __M_writer('\r\n    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis egestas pulvinar nisi ac euismod. Cras at elit vel justo consectetur tempor ullamcorper vel ligula. Etiam sit amet nunc felis. Aenean tristique molestie mattis. Etiam neque arcu, semper non posuere at, tincidunt eu elit. Praesent eu ipsum sed mi egestas pulvinar ac at sapien. In bibendum, nunc eget faucibus euismod, diam ligula tempus libero, at pretium erat tortor a ante. Suspendisse elementum turpis a egestas consectetur. Nulla commodo sem nulla. Maecenas condimentum sem in fermentum volutpat. Suspendisse interdum ac ligula non pellentesque. Donec erat massa, cursus a aliquam eget, pretium eget urna. Mauris faucibus ipsum vel suscipit imperdiet. Nam interdum sem eu tellus ornare condimentum vel id est.<br />\r\n        <br />\r\n        Cras tristique, nibh in sagittis faucibus, nunc nisi lacinia turpis, quis posuere dui nunc id lorem. Nunc nibh erat, facilisis sit amet consectetur sit amet, elementum vel metus. Suspendisse rhoncus in urna eu faucibus. Nam convallis aliquam velit. Curabitur vitae mi efficitur, iaculis nunc eget, mattis libero. Nunc fringilla diam sed massa efficitur, a fringilla urna vehicula. Nunc in leo tempus odio congue eleifend. Ut egestas vehicula tellus nec pellentesque. Cras et dignissim tellus. Maecenas fermentum sem ante, vitae finibus eros tincidunt vel. Phasellus velit lacus, pretium ac sem id, egestas vehicula erat. Fusce facilisis ante vitae aliquam mollis. Vivamus lacinia interdum magna, in elementum erat dapibus in. Nullam porttitor consectetur augue ac dignissim. Fusce vel dui nulla. Aliquam sit amet nunc eget nisl commodo posuere ut varius nisi.<br />\r\n        <br />\r\n        Nunc malesuada sodales orci, nec vulputate enim pretium at. Morbi quis urna tellus. Vestibulum tristique dui odio, a dapibus magna pellentesque et. Maecenas eget ante sed urna lacinia egestas. Suspendisse tincidunt egestas viverra. Morbi ultricies ex mauris, a condimentum nulla faucibus ac. Aliquam eget orci ac dolor pulvinar aliquet non vitae sapien. Morbi vitae viverra lectus. Donec vitae posuere ipsum. Sed sit amet massa sollicitudin, tempus orci eget, maximus ligula. Nulla urna erat, dictum quis nisl sed, egestas lacinia orci. Aliquam aliquam interdum odio, non dapibus nunc elementum in. Integer ac purus pellentesque, pretium nibh at, mattis orci.<br />\r\n        <br />\r\n        Aenean non sodales eros. Mauris consectetur tortor ornare tempus rhoncus. Ut accumsan velit varius neque feugiat, vitae vestibulum libero tempus. Quisque sagittis elit vitae tellus pulvinar dapibus. Cras fermentum ante non turpis faucibus, ut condimentum quam semper. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Aliquam tincidunt, odio in volutpat tincidunt, odio nisl auctor lectus, nec porttitor elit quam vitae felis. Aliquam vel dolor a ligula dapibus interdum non eu enim. Sed ac felis rutrum, consequat magna vel, rutrum mauris. Etiam tincidunt nulla ut convallis interdum. Etiam in fermentum erat, in elementum arcu. Donec ultricies ex at nunc iaculis mattis eu at magna.<br />\r\n        <br />\r\n        Aliquam erat volutpat. Suspendisse id arcu nec tortor vulputate feugiat. Donec molestie faucibus elit, id accumsan nunc maximus in. Vestibulum cursus, risus quis consequat porta, odio augue euismod arcu, in elementum metus tellus finibus turpis. Sed sollicitudin massa laoreet tempor dignissim. Pellentesque fermentum, turpis vitae pulvinar viverra, metus nisi tincidunt ex, a lobortis nisl purus ac dui. Donec volutpat sodales lorem ac efficitur. Phasellus ornare feugiat iaculis. Nullam lacinia, nisi vitae gravida tincidunt, ligula magna tincidunt leo, non sagittis tortor lorem ac tortor. Cras mollis mollis lacinia. Curabitur eget orci et justo pellentesque congue non sed justo.\r\n    </p>\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "C:/Users/Chelsey/Documents/IS411_413/FOMO/FOMO/FamilyOrientedMusicOperation/homepage/templates/about.html", "uri": "about.html", "source_encoding": "utf-8", "line_map": {"28": 0, "37": 1, "42": 5, "47": 18, "53": 3, "59": 3, "65": 7, "71": 7, "77": 71}}
__M_END_METADATA
"""
